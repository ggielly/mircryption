Imports Microsoft.VisualBasic
Imports System
Imports System.Runtime.InteropServices

Namespace CryptoWrapper
    Public Class CryptoWrapper

        <DllImportAttribute("mircryption.dll")> _
        Public Shared Function DecryptString(<MarshalAs(UnmanagedType.AnsiBStr)> ByVal password As String, <MarshalAs(UnmanagedType.AnsiBStr)> ByVal cryptedtext As String, <MarshalAs(UnmanagedType.AnsiBStr)> ByVal plaintext As String, ByVal maxresultlen As Integer) As String
        End Function

        <DllImportAttribute("mircryption.dll")> _
        Public Shared Function EncryptString(<MarshalAs(UnmanagedType.AnsiBStr)> ByVal password As String, <MarshalAs(UnmanagedType.AnsiBStr)> ByVal plaintext As String, <MarshalAs(UnmanagedType.AnsiBStr)> ByVal crypttext As String, ByVal maxresultlen As Integer) As String
        End Function

        <DllImportAttribute("mircryption.dll")> _
        Public Shared Sub FreeResultString(<MarshalAs(UnmanagedType.AnsiBStr)> ByVal text As String)
        End Sub

        <DllImportAttribute("mircryption.dll")> _
        Public Shared Function GetVersionString() As String
        End Function
    End Class
End Namespace


