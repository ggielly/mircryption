'Team AGGRESSiON 2oo5 aka -ARN

Imports Microsoft.VisualBasic
Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms

Namespace CryptoWrapper
    Public Class Form1
        Inherits Form
        Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
        Private components As Container = Nothing


        Public Sub New()
            InitializeComponent()
            
        End Sub

        Protected Overloads Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso Not components Is Nothing Then
                components.Dispose()
            End If
            MyBase.Dispose(disposing)
        End Sub
        Friend WithEvents Button1 As System.Windows.Forms.Button
        Friend WithEvents Label1 As System.Windows.Forms.Label
        Friend WithEvents Label2 As System.Windows.Forms.Label
        Friend WithEvents TextBox2 As System.Windows.Forms.TextBox

        Private Sub InitializeComponent()
            Me.TextBox1 = New System.Windows.Forms.TextBox
            Me.Button1 = New System.Windows.Forms.Button
            Me.Label1 = New System.Windows.Forms.Label
            Me.Label2 = New System.Windows.Forms.Label
            Me.TextBox2 = New System.Windows.Forms.TextBox
            Me.SuspendLayout()
            '
            'TextBox1
            '
            Me.TextBox1.Location = New System.Drawing.Point(8, 32)
            Me.TextBox1.Name = "TextBox1"
            Me.TextBox1.Size = New System.Drawing.Size(272, 20)
            Me.TextBox1.TabIndex = 0
            Me.TextBox1.Text = ""
            '
            'Button1
            '
            Me.Button1.Location = New System.Drawing.Point(24, 120)
            Me.Button1.Name = "Button1"
            Me.Button1.Size = New System.Drawing.Size(240, 32)
            Me.Button1.TabIndex = 1
            Me.Button1.Text = "Decrypt it sUckA"
            '
            'Label1
            '
            Me.Label1.Location = New System.Drawing.Point(8, 8)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(272, 16)
            Me.Label1.TabIndex = 2
            Me.Label1.Text = "Fish key Below"
            '
            'Label2
            '
            Me.Label2.Location = New System.Drawing.Point(10, 64)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(272, 16)
            Me.Label2.TabIndex = 3
            Me.Label2.Text = "Encrypted text below please ;)"
            '
            'TextBox2
            '
            Me.TextBox2.Location = New System.Drawing.Point(8, 88)
            Me.TextBox2.Name = "TextBox2"
            Me.TextBox2.Size = New System.Drawing.Size(272, 20)
            Me.TextBox2.TabIndex = 4
            Me.TextBox2.Text = ""
            '
            'Form1
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(292, 266)
            Me.Controls.Add(Me.TextBox2)
            Me.Controls.Add(Me.Label2)
            Me.Controls.Add(Me.Label1)
            Me.Controls.Add(Me.Button1)
            Me.Controls.Add(Me.TextBox1)
            Me.Name = "Form1"
            Me.Text = "Form1"
            Me.ResumeLayout(False)

        End Sub

        Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
            Dim keystr1, keystr2 As String
            keystr1 = TextBox2.Text
            If keystr1.StartsWith("+OK") Then
                keystr2 = keystr1.Remove(0, 4)
                Dim str As String = CryptoWrapper.DecryptString(TextBox1.Text, keystr2, Nothing, 0)
                MessageBox.Show(str)
                CryptoWrapper.FreeResultString(str)
            Else
                keystr2 = keystr1
                Dim str As String = CryptoWrapper.DecryptString(TextBox1.Text, keystr2, Nothing, 0)
                MessageBox.Show(str)
                CryptoWrapper.FreeResultString(str)
            End If
        End Sub
    End Class
End Namespace
