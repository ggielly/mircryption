Mirccryption/FiSH compatible Blowfish IRC encryption/decryption for Delphi v0.2
This version uses madShi's blowfish unit, which is freeware. www.madshi.net
Based on Crypt-ircBlowfish-1.0 for Perl
Ported by godfucked
2006-01-22

Tested on Delphi 7 / Kylix 3.

Check project1.dpr for example usage.

ircBlowFish unit implements the following two public functions:
function encrypt(dText, key: string): string;
  dText: cleartext
  key: encryption key for Blowfish
  Returns ciphertext encoded by not-standard-base64

function decrypt(eText, key: string): string;
  eText: not-standard-base64 encoded ciphertext
  key: encryption key for Blowfish
  Returns cleartext

Dont forget to add +OK prefix before sending the message.