BrotBueXes URL-Catcher v0.17 (March 2003)


Overview:

This Script can catch URLs (or other wildcard-matched strings) from chan, action,
notice, query, chat or input messages. The URLs are stored in a tab-separeted
history-file. You can browse, search, export and manage this History over
a listboxwindow and different dialogs. Check the Screenshot as explanation.

Includes:
readme.txt         This Documentation
bb-urlcatcher.mrc  The URL-Catcher-Script
bb-urlcattrig.mrc  A !url remote trigger to let people search trough the history
                   of a chan (Please change the Temp-Path in the Script!)

Features:

 - Can catch every (wildcard-matched) string you want
 - store more information as mirc (Date/Time, Nick, Chan, Source-Message)
 - Searchfunction global or over a column (only Nicks, only Chans, etc.)
 - Customizable via Optionsdialog
 - Excludefunction for (wildcard-matched) Chans, Nicks and Messagestrings
 - Can create IE-Favorites
 - Can export selected URL(s) to a CSS-styled HTML-File
 - Dupedetection (can replace old dupes with the new entry)
 - Multiserver SendTo-Menu (Chans, Querys, Chats)
 - You can add your own URLs


Requires:

mIRC. Don't know exact Versionnumber, its developed on 6.03, and its not working on 5.82.


Usage:

Put the bb-urlcatcher.mrc in a path you want and load it in mirc via
"/load -rs <path>\bb-urlcatcher.mrc". Its open a Config-Dialog where you can
customize the script. You can access the Functions via Popups from Menubar,
Nicklist, Channel-, Server-, Query- or Chat-Window.


Settings:

General:
 Catch URLs
    Global Enable / Disable the catch-function.
 Detect & Replace Dupes
    Check for Dupes in History, add the new and remove the old item.
 max. URLs
    Set the max amount of URLs stored in history. (reduce the speed!)

Export:
 IE-Favorites-Folder
    Select the Destination-Folder for Favorites.
 Make Nick/Chan Subfolders
    Create Subfolders for Nick/Chan in IE-Favorites-Folder and put Favorites in it.
 HTML-Export-Filter
    Select the Destination-Folder for the HTML.

Window Settings:
 Open on Start
    Select to open BB-URL-History-Window on mIRC-Start.
 Mark new URLs
    New URLs marked green.
 Desktop-Window
    Open BB-URL-History-Window as Desktop-Window.
 Place on Top
    Place BB-URL-History-Window on Top. (activates Desktop-Window)

Column Positions:
    Customize the columnsposition in BB-URL-History-Window.
    Requires reopen of BB-URL-History-Window to take effect.

On Catch:
 Open Window
    Opens the BB-URL-History-Window when a url is catched.
 Play Sound
    Make beep when a url is catched.
 Highlight Switchbar
    Highlight the Switchbar-Item of the BB-URL-History-Window when a url is catched.
 Open URL
    Open the catched urls automatically.

Open URLs:
 Open a new Browserwindow
    Send URL to a new Browserwindow
 Activate Browser-Window
    Activates the Browserwindow.
 Open via /run instead of /url
    "Executes" URLs. Its dangerous, use with caution! (disables Auto-Open URL, /url-Settings)


URL-Types / Wildcardstrings:
    Here you can manage the url-detection. Add the (wildcard) strings you want.
    Buttons for predefined protocols (http, ftp, ed2k).

Excludes / Wildcardstrings:
 Nicks
    You can add Nicks or Wildcard-Strings where urls from this people are not catched.
 Chans
    You can add Chans or Wildcard-Strings where urls from this chans are not catched.
 MSGs
    You can add Wildcard-Strings where urls from msgs matched with this strings are not catched.


Reset
    Reset to the Default Settings
Remove excluded Items
    Removes all urls from the history file that match the exclude settings. (only since last dialog-init!)
    Warning: Can take a while!


Thanks to

dohcan for the very nice mirc-dialog-studio www.mircscripts.org/dstudio/
www.mircscripts.org for the nice snippets and tuts
mcnuke and gilly for testing
and to my doctor for the sick leave of 1,5 weeks so i could push the functions of that script. :)


I hope its working for you, when you have problems, email me at fridolin@brotbuexe.de
or contact me at ircnet.

More of my scripts you can get from www.brotbuexe.de/mircscripts/ (german page)

BrotBueXe


ToDo
        select programs to urls
        catch email-adresses (ugly wildcardstyle / like a hostmask)
        hashtable for settings
        select found option in searchdialog, select all option in popupmenu
        html-export: sortable via javascript *g*, calculate also link-colors, cut too long urls
        fix wildcardmatching (check if * exists in %match?)
        check changed items in config dialog (reopen url-window)
        open dialogs on desktop when bb-url-catcher-window also on desktop
        use regional settings for date/time


Known Bugs/Limitations

        every time a dupereplace of a new-marked url is done, 1 more old item is marked :/ i'll try to fix this
        www.*.* removes last wildcard matched www.*.* url :/ (workaround added)


History

v0.01 - Initial Testing Release :)

v0.02 - Added Navigation in Detaildialog
        Added URL-Icons
        Added Search-Dialog (not working yet :/ )

v0.03 - Fixed sort of urllist
        Search-Dialog first working version

v0.04 - Search-Next added

v0.05 - removed the crap hashtable-shit, use now a tab-delimeted file
        can convert the old hashtable via menuitem, or via alias bb-url-catcher-convert

v0.06 - catch own urls

v0.07 - add configure dialog
        can now make favorites for internet explorer
        types of urls (wildcards) now configurable
        different actions on catch selectable
        you can exclude chans, nicks and msgs (wildcards allowed)
        popups to quick exclude chans/nicks
        can remove excludes later from history-file
        dupedetection can be disabled

v0.08 - bugfixes
          remove with rightclick doesnt work

v0.09 - Multiserver send-to-popupmenu in BB-URL-Catcher-Window (Chans, Querys, Chats)
        Unload-Messages added

v0.10 - Changed the default wildcardstrings (replace ? to :, ? was a workaround from a very old version)
        HTTP/FTP/ED2K buttons only add wildcardstrings that not in list
        Now you can add a url manually via dialog
        Config-Dialog has now right tab-order
        Use now $input for question-dialogs
        Different small modifications (see options)
        Added more options (window-behavior, urlopen-behavior, etc.)
        Can now create nick/chan subfolders on favorite-dir
        Url can now open via /run (no autoopen) instead /url (dangerous!, but its give a warning)
        fixed bug, no catch in query/chat windows on input
        very nice html-export (use layout-settings from mIRC :)

v0.11 - Changed ftp.*.* to ftp.*.??* and www.*.* to www.*.??*
        bugfix in export ( wrote $$ instead of && :)

v0.12 - the td1/td2 colors in html export was not dimmed correctly

v0.13 - bugfix, dupecheck dont work

v0.14 - changed config dialog to 2 tabs

v0.15 - now use highlightcolor for mark new urls

v0.16 - fixed bug ('/msg bla http://www.test.de' in a chan-window put this url as sayed in this chan)

v0.17 - fixed bug with spaces in paths

