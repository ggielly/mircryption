{*************************************************}
{				                  }
{  TFileDropper				          }
{  Copyright �1999-2001 Workshell Software.       }
{					          }
{  Version 1.0				          }
{					          }
{*************************************************}

------
 Info
------

TFileDropper lets you easily support drag & drop from Windows Explorer and
File Manager.

As well as just adding files, if you drag a folder it will add the files
within the folder as well, and if thats not enough, it will add the files
in ALL the subfolders of that folder.

TFileDropper is based around the C++ Builder Workshop TFileDropper sported
in the PC Plus (July 1999) computer magazine over in the UK.

After translating we added a bit here and there and removed some unwanted
code.

You may distribute TFileDropper freely as long as it is in it's orignal ZIP
file and that the contents remains unmodified.

---------
 Support
---------

As with all our components, support is available online at our website or
through our e-mail address:

workshell@mail.com

---------------------- 
 Warranty & Liability
----------------------

There is no warranty, all software is supplied as it.
We will not be held liable for any damage done to anything through the use
of this software etc.

------------
 Contacting
------------

Web      -> http://www.workshell.co.uk/

E - Mail -> filedrop@workshell.co.uk