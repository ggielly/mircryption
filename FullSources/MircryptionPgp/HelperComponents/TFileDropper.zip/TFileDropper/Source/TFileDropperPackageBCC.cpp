//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("TFileDropperPackageBCC.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("Dropper.pas");
USERES("Dropper.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
	return 1;
}
//---------------------------------------------------------------------------
