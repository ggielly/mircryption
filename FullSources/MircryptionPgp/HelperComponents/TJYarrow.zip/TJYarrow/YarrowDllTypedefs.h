// based on yarrow.h

#ifndef YarrowDllTypedefsh
#define YarrowDllTypedefsh



typedef int (__declspec(dllimport) *TD_prngOutput)(BYTE *outbuf,UINT outbuflen);
typedef int (__declspec(dllimport) *TD_prngStretch)(BYTE *inbuf,UINT inbuflen,BYTE *outbuf,UINT outbuflen);
typedef int (__declspec(dllimport) *TD_prngInput)(BYTE *inbuf,UINT inbuflen,UINT poolnum,UINT estbits);
typedef int (__declspec(dllimport) *TD_prngForceReseed)(LONGLONG ticks);
typedef int (__declspec(dllimport) *TD_prngAllowReseed)(LONGLONG ticks);
typedef int (__declspec(dllimport) *TD_prngProcessSeedBuffer)(BYTE *buf,LONGLONG ticks);
typedef int (__declspec(dllimport) *TD_prngSlowPoll)(UINT pollsize);

/* Error Codes */
typedef enum prng_error_status {
	PRNG_SUCCESS = 0,
	PRNG_ERR_REINIT,
	PRNG_ERR_WRONG_CALLER,
	PRNG_ERR_NOT_READY,
	PRNG_ERR_NULL_POINTER,
	PRNG_ERR_LOW_MEMORY,
	PRNG_ERR_OUT_OF_BOUNDS,
	PRNG_ERR_COMPRESSION,
	PRNG_ERR_NOT_ENOUGH_ENTROPY,
	PRNG_ERR_MUTEX,
	PRNG_ERR_TIMEOUT,
	PRNG_ERR_PROGRAM_FLOW
} prng_error_status;


enum user_sources {
	USERSOURCE1 = 0,
	USERSOURCE2,
	USERSOURCE3,
	USER_SOURCES  /* Leave as last source */
};




#endif