// From MS Web Page http://support.microsoft.com/support/kb/articles/Q178/8/93.asp

   //******************
   //Header
   //******************

   #include <windows.h>

   #define TA_FAILED 0
   #define TA_SUCCESS_CLEAN 1
   #define TA_SUCCESS_KILL 2
   #define TA_SUCCESS_16 3
   #define TA_CANTOPEN 4
   #define TA_NOP 9


   int TerminateApp( DWORD dwPID, DWORD dwTimeout, bool polite ) ;
   int Terminate16App( DWORD dwPID, DWORD dwThread, WORD w16Task, DWORD dwTimeout );
   DWORD LookUpProcessName(char *name);
   DWORD LookUpWindowTitle(char *title);