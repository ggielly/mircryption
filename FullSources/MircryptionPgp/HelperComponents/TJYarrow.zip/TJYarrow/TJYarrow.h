//---------------------------------------------------------------------------

#ifndef TJYarrowH
#define TJYarrowH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>

#include "YarrowDllTypedefs.h"
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------


#include <shellapi.h>
//#include <process.h>
//#include <stdlib.h>
//#include <masks.hpp>


extern char *prng_error_strings[];


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPSAPI
{
public:
	CPSAPI();
	virtual ~CPSAPI();

	BOOL Initialize(void);

	BOOL EnumDeviceDrivers(void);
	BOOL EnumProcesses(void);
	BOOL EnumProcessModules(DWORD dwProcessId);
//	BOOL EnumModuleFileName(HANDLE hProcess);

	virtual BOOL OnDeviceDriver(LPVOID lpImageBase);
	virtual BOOL OnProcess(LPCTSTR lpszFileName, DWORD ProcessID);
	virtual BOOL OnModule(HMODULE hModule, LPCTSTR lpszModuleName, LPCTSTR lpszPathName);

protected:
	bool	m_bNeedPSAPI;

	// Windows NT variables
	HMODULE	m_modPSAPI;
	HMODULE	m_modVDMDBG;

	// Windows 95 variables
};







//---------------------------------------------------------------------------
class searchCPSAPI : public CPSAPI
{
protected:
	DWORD procid;
	AnsiString procname,wintitle;
public:
	DWORD LookUpProcessName(AnsiString name);
	DWORD LookUpWindowTitle(AnsiString title);
public:
	BOOL OnDeviceDriver(LPVOID lpImageBase);
	BOOL OnProcess(LPCTSTR lpszFileName, DWORD ProcessID);
	BOOL OnModule(HMODULE hModule, LPCTSTR lpszModuleName, LPCTSTR lpszPathName);
};



class PACKAGE TJYarrow : public TComponent
{
private:
	// dll function pointers
	HINSTANCE Dllp;
	TD_prngOutput prngOutput;
	TD_prngStretch prngStretch;
	TD_prngInput prngInput;
	TD_prngForceReseed prngForceReseed;
	TD_prngAllowReseed prngAllowReseed;
	TD_prngProcessSeedBuffer prngProcessSeedBuffer;
	TD_prngSlowPoll prngSlowPoll;
private:
	bool sufficiententropydelay;
	bool didstartup;
	bool didseed;
	bool FrontendIsRunning;
	bool AutostartFrontend;
	bool AutostopFrontend;
protected:
	// properties
	AnsiString BaseDirectory;
	AnsiString FrontendName;
	AnsiString ResultString;
	TNotifyEvent FOnSeed;
public:
	__fastcall TJYarrow(TComponent* Owner);
	__fastcall ~TJYarrow();
public:
	void Initialize();
	int RunFrontend();
	int ShutdownFrontend();
private:
	// dll management
	bool LoadPrngDll();
	bool UnLoadPrngDll();
	bool LookupDllFuncPointers();
	bool ErrorIfCantLoadDll();
	bool TryReloadFrontend();
public:
	DWORD LookupProcessName(char *procname);
public:
	// seed procedures
	void __fastcall TimeStampSeed();
	void Seed();
public:
	// main user callable rng functions
	int MakeRandString(char *buf,int length);
	int MakeRandPrettyString(int length);
	int MakeIrcSafeRandString(int length);
	int MakeNoWhitespaceRandString(int length);
public:
	// convert an error # to a string (you can just observer property ResultStr);
	AnsiString PrngErrorString(int index);
public:
	// accessors
	__fastcall TNotifyEvent get_FOnSeed() {return FOnSeed;};
	__fastcall void set_FOnSeed(TNotifyEvent ev) {FOnSeed=ev;};
	__fastcall AnsiString get_ResultString() {return ResultString;};
	__fastcall void set_ResultString(AnsiString &instring) {;};
	__fastcall AnsiString get_BaseDir() {return BaseDirectory;};
	__fastcall void set_BaseDir(AnsiString &instring) {;}; //if (instring!="") BaseDirectory=instring;};
__published:
	// published properties and events
	__property AnsiString BaseDir = {read=get_BaseDir, write=set_BaseDir};
	__property AnsiString ResultStr = {read=get_ResultString, write=set_ResultString};
	__property TNotifyEvent OnSeed = {read=get_FOnSeed, write=set_FOnSeed};
public:
	// ms appkill
	int TerminateApp( DWORD dwPID, DWORD dwTimeout, bool polite ) ;
	int Terminate16App( DWORD dwPID, DWORD dwThread, WORD w16Task, DWORD dwTimeout );
	DWORD LookUpProcessName(AnsiString name);
	DWORD LookUpWindowTitle(AnsiString title);
};
//---------------------------------------------------------------------------

 
#endif
 