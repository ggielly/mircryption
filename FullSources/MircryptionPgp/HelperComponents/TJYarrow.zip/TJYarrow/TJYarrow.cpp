//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "TJYarrow.h"



#pragma package(smart_init)
//---------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//


char *prng_error_strings[]={"success","reinit error","wrong caller","not ready","null pointer","low memory","out of bounds","compression error","not enough entropy","mutex error (frontend tray icon not accessible?)","timeout","program flow"};


//---------------------------------------------------------------------------
static inline void ValidCtrCheck(TJYarrow *)
{
	new TJYarrow(NULL);
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
namespace Tjyarrow
{
	void __fastcall PACKAGE Register()
	{
		TComponentClass classes[1] = {__classid(TJYarrow)};
		RegisterComponents("TJComponents", classes, 0);
	}
}
//---------------------------------------------------------------------------






//---------------------------------------------------------------------------
__fastcall TJYarrow::TJYarrow(TComponent* Owner)
	: TComponent(Owner)
{
	// initialize dll pointer to indicate the dll is not yet loaded
	Dllp=NULL;
	// clear result
	ResultString="";
	// clear events
	FOnSeed=NULL;
	// defaults
	AutostartFrontend=true;
	AutostopFrontend=true;
	// init
	sufficiententropydelay=false;
	didseed=false;
	FrontendIsRunning=false;
	
	// set base dll directory
	char DllFileName[500];
	GetModuleFileName( HInstance,DllFileName, sizeof (DllFileName) );
	BaseDirectory=ExtractFilePath(DllFileName);
}


__fastcall TJYarrow::~TJYarrow()
{
	// deinitialize
	// designtime vs runtime
	if (ComponentState.Contains(csDesigning))
		;
	else
		{
		if (AutostopFrontend)
			ShutdownFrontend();
		}
	UnLoadPrngDll();
}


void TJYarrow::Initialize()
{
	FrontendName=BaseDirectory+"FrontEnd.exe";

	// designtime vs runtime
	if (ComponentState.Contains(csDesigning))
		;
	else
		{
		if (AutostartFrontend)
			RunFrontend();
		}
}



/*
void __fastcall TJYarrow::set_BaseDir(AnsiString &instring)
{
	if (instring!="")
		BaseDirectory=instring;
	else
		BaseDirectory=ExtractFilePath(Application->ExeName);
}
*/

//---------------------------------------------------------------------------


int TJYarrow::RunFrontend()
{
	// retun -1 on couldnt run
	// return 0 if already running
	// return 1 on ran
	// make sure the tray is running if we are responsible
	// return true of so, and false if not
	int retv=0;
	AnsiString args="";
	AnsiString dir="";
	int showmode=SW_SHOWNORMAL;
	DWORD procid;

	// we are responsible for starting tray
	procid=LookUpProcessName(FrontendName);
	if (procid==0)
		{
		// we need to launch it
		dir=ExtractFilePath(FrontendName.c_str());
		SetCurrentDir(dir);		
		// ShowMessage("Attempting to load "+FrontendName+" with curdir = "+GetCurrentDir()+" and rundir="+dir+".");
		ShellExecute(NULL, "open", FrontendName.c_str(), args.c_str(), dir.c_str(),showmode);
		// give it a bit of time to launch
		sufficiententropydelay=false;
		Sleep(100);
		procid=LookUpProcessName(FrontendName);
		if (procid==0)
			Sleep(1000);
		procid=LookUpProcessName(FrontendName);
		if (procid==0)
			{
//			ShowMessage("was not able to load frontend.");
			retv=-1;
			}
		else
			retv=1;
		}
//	else
//		ShowMessage("NOT Attempting to load "+FrontendName+" with curdir = "+GetCurrentDir());

	return retv;
}


int TJYarrow::ShutdownFrontend()
{
	// return -1 on still running, couldnt shut down
	// return 0 on was not running
	// return 1 on was running, and killed it
	DWORD procid;
	int count=0;

	// kill the tray util and make sure it dead
	while ((procid=LookUpProcessName(FrontendName))!=0 && count<10)
		{
		TerminateApp(procid,1000,true);
		++count;
		}
	if (count==0)
		return 0;
	else if (count>=10)
		return -1;
	return 1;
}


bool TJYarrow::LoadPrngDll()
{
	// load yarrow dlls
	bool bretv;

	// unload if already loaded
	if (Dllp!=NULL)
		UnLoadPrngDll();
	// now load it
	Dllp=LoadLibrary((BaseDirectory+"prngcore.dll").c_str());
	if (!Dllp)
		Dllp=LoadLibrary((BaseDirectory+"\\prngcore.dll").c_str());
	if (!Dllp)
		Dllp=LoadLibrary("../prngcore.dll");
	if (!Dllp)
		Dllp=LoadLibrary("prngcore.dll");
	if (Dllp)
		{
		bretv=LookupDllFuncPointers();
		if (bretv)
			{
			ResultString="prng.dll loaded and exported functions looked up successfully.";
			if (!didseed)
				Seed();
			// allow the entropy generator to reseed
			prngAllowReseed(500);
			}
		else
			{
			ResultString="Error: prng.dll loaded but failts to lookup exported function pointers.";
			UnLoadPrngDll();
			}
		}
	else
		ResultString="Error: prng.dll could not be loaded (not found?).";
	return bretv;
}


bool TJYarrow::UnLoadPrngDll()
{
	// unload yarrow dlls
	if (Dllp!=NULL)
		{
		FreeLibrary(Dllp);
		Dllp=NULL;
		}
	return true;
}


bool TJYarrow::LookupDllFuncPointers()
{
	// load dll function addresses (note they dont have _ prefixes)
	prngOutput = (TD_prngOutput)GetProcAddress(Dllp,"prngOutput");
	prngStretch = (TD_prngStretch)GetProcAddress(Dllp,"prngStretch");
	prngInput = (TD_prngInput)GetProcAddress(Dllp,"prngInput");
	prngForceReseed = (TD_prngForceReseed)GetProcAddress(Dllp,"prngForceReseed");
	prngAllowReseed = (TD_prngAllowReseed)GetProcAddress(Dllp,"prngAllowReseed");
	prngProcessSeedBuffer = (TD_prngProcessSeedBuffer)GetProcAddress(Dllp,"prngProcessSeedBuffer");
	prngSlowPoll = (TD_prngSlowPoll)GetProcAddress(Dllp,"prngSlowPoll");

	if (prngOutput==NULL || prngStretch==NULL || prngInput==NULL || prngForceReseed==NULL || prngAllowReseed==NULL || prngProcessSeedBuffer==NULL || prngSlowPoll==NULL)
		return false;
	return true;
}


bool TJYarrow::ErrorIfCantLoadDll()
{
	// load the dll ONLY if it is not already loaded, and return true if loaded, or false if not with error in resultstr
	if (Dllp==NULL)
		LoadPrngDll();
	if (Dllp!=NULL)
		return true;
	return false;
}


AnsiString TJYarrow::PrngErrorString(int index)
{
	// just convert a yarror error# into a string
	if (index>=0 && index<=9)
		return AnsiString(prng_error_strings[index]);
	else
		return "Bad Error #";
}

void TJYarrow::Seed()
{
	// any addiitonal seeding of the entropy generator can be done here,
	// like seeding with current time.
	// Plus, we trigger a user-defined seed function if its available
	if (!ErrorIfCantLoadDll())
		return;

	didseed=true;
	TimeStampSeed();

	if (FOnSeed!=NULL)
		FOnSeed(this);
}
//---------------------------------------------------------------------------
	

	









//---------------------------------------------------------------------------
void __fastcall TJYarrow::TimeStampSeed()
{
	// add some entropy by adding current timestamps

	DWORD dwTickCount = GetTickCount();
	prngInput((BYTE *)&dwTickCount, sizeof dwTickCount,USERSOURCE1,1);

	SYSTEMTIME sdtSystemTime;
	GetSystemTime(&sdtSystemTime);
	prngInput((BYTE *)&sdtSystemTime, sizeof sdtSystemTime,USERSOURCE1,1);
}



int TJYarrow::MakeRandString(char *buf, int length)
{
	// higher level, use prngOuput to make a text readable [0-9a-zA-Z] string of specified length
	AnsiString retstring="";
	int count;
	int index;
	unsigned char c;
	int retv;

	if (!ErrorIfCantLoadDll())
		return PRNG_ERR_REINIT;

	retv=prngOutput(buf,length);
	if (retv==PRNG_ERR_MUTEX)
		{
		// try to restart frontend and try again
		if (!TryReloadFrontend())
			return PRNG_ERR_REINIT;
		retv=prngOutput(buf,length);
		}

	if (retv!=PRNG_SUCCESS)
		{
		// store error string in property
		ResultString=PrngErrorString(retv);
		// let's try again to load the frontend...
		return retv;
		}

	buf[length]='\0';
	return retv;
}


int TJYarrow::MakeRandPrettyString(int length)
{
	unsigned char *buf=new char[length+1];
	int count;
	int retv;
	unsigned char c;
	int index;
	unsigned char ascis[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	int maxindex=strlen(ascis);

	retv=MakeRandString(buf,length);
	for (count=0;count<length;++count)
		{
		c=buf[count];
		index=c%maxindex;
		buf[count]=ascis[index];
		}
	ResultString=AnsiString((char *)buf);
	delete buf;
	return retv;
}

int TJYarrow::MakeIrcSafeRandString(int length)
{
	unsigned char *buf=new char[length+1];
	int count;
	int retv;
	unsigned char c;

	retv=MakeRandString(buf,length);
	// make sure some irc dangerous characters are not used
	for (count=0;count<length;++count)
		{
		c=buf[count];
		if (c<4 || c==13 || c==15 || c==22 || c==10 || c==9 || c==32 || c==31 || c==33 || c==36 || c==40 || c==41 || c==44 || c==34 || c==47 || c==37 || c==48)
			buf[count]=c+64;
		if (c==127)
			buf[count]=48;
		if (c==255)
			buf[count]=49;
		}
	ResultString=AnsiString((char *)buf);
	delete buf;
	return retv;
}

int TJYarrow::MakeNoWhitespaceRandString(int length)
{
	unsigned char *buf=new char[length+1];
	int count;
	int retv;
	unsigned char c;

	retv=MakeRandString(buf,length);
	// just modify 0 bytes and newlines
	for (count=0;count<length;++count)
		{
		c=buf[count];
		if (c==0 || c==13 || c==10 || c==9 || c==32)
			buf[count]=c+64;
		}
	ResultString=AnsiString((char *)buf);
	delete buf;
	return retv;
}




bool TJYarrow::TryReloadFrontend()
{
	// unload and reload the front end and re-init prng.dll
	int retv;

	UnLoadPrngDll();
	Sleep(200);
	retv=ShutdownFrontend();
	if (retv==1)
		Sleep(1000);
	retv=RunFrontend();
	if (retv==1)
		Sleep(1000);
	if (!ErrorIfCantLoadDll())
		return false;
	return true;
}










// THE CODE BELOW IS FOR STARTING AND STOPPING THE FRONTEND.EXE tool
// It's a lot of work to find and kill other apps :(







// From MS Web Page http://support.microsoft.com/support/kb/articles/Q178/8/93.asp

   //******************
   //Source
   //******************

   #include "mskillprocess.h"
   #include <vcl.h>
   #include <vdmdbg.h>
   #include <syncobjs.hpp>

   typedef struct
   {
      DWORD   dwID ;
      DWORD   dwThread ;
   } TERMINFO ;

   // Declare Callback Enum Functions.
   BOOL CALLBACK TerminateAppEnum( HWND hwnd, LPARAM lParam ) ;

   BOOL CALLBACK Terminate16AppEnum( HWND hwnd, LPARAM lParam ) ;

   /*----------------------------------------------------------------
   DWORD WINAPI TerminateApp( DWORD dwPID, DWORD dwTimeout )

   Purpose:
      Shut down a 32-Bit Process (or 16-bit process under Windows 95)

   Parameters:
      dwPID
         Process ID of the process to shut down.

      dwTimeout
         Wait time in milliseconds before shutting down the process.
         // ATTN ADDED: wait time of 0 means don't force it

   Return Value:
      TA_FAILED - If the shutdown failed.
      TA_SUCCESS_CLEAN - If the process was shutdown using WM_CLOSE.
      TA_SUCCESS_KILL - if the process was shut down with
         TerminateProcess().
      NOTE:  See header for these defines.
   ----------------------------------------------------------------*/
   int TJYarrow::TerminateApp( DWORD dwPID, DWORD dwTimeout, bool polite )
   {
      HANDLE   hProc ;
      int   dwRet ;
      int nret;

      // If we can't open the process with PROCESS_TERMINATE rights,
      // then we give up immediately.
      hProc = OpenProcess(SYNCHRONIZE|PROCESS_TERMINATE, FALSE, dwPID);
      if(hProc == NULL)
      	{
         // we thought this meant that the process was alive and not accessible
         // BUT we find that it sometimes means that the OpenProcess command killed the process
         // and so it's not nesc. an error.
         // so what we want is to see if it exists and if so return error, if not return success
	 //  ShowMessage("OpenProcess Permission error.");
         return TA_CANTOPEN;
         }

      // TerminateAppEnum() posts WM_CLOSE to all windows whose PID
      // matches your process's.
      EnumWindows((WNDENUMPROC)TerminateAppEnum, (LPARAM) dwPID) ;

      // Wait on the handle. If it signals, great. If it times out,
      // then you kill it.
      nret=WaitForSingleObject(hProc, dwTimeout);
      // ShowMessage("WaitForSingleObject returned: "+IntToStr(nret)+"  (wrError=="+wrError+"  wrTimeout=="+wrTimeout+"  wrSignaled="+wrSignaled+"  wrAbandoned="+wrAbandoned+").");
      if (nret==wrSignaled)
        dwRet=TA_SUCCESS_CLEAN;
      else if (nret==wrError)
      	{
        // ShowMessage("Wait error.");
        dwRet=TA_FAILED;
        }
      else if (nret==wrAbandoned)
          {
          // not sure actually what this means - think it means program is gone
	  //   ShowMessage("Abandoned.");
          dwRet=TA_SUCCESS_CLEAN;
          }
      else if (polite)
          dwRet=TA_FAILED;
      else
      	{
        // force it to die
	// ShowMessage("FORCE KILLING.");
        nret=TerminateProcess(hProc,0);
        if (!nret)
        	{
		// ShowMessage("Forced terminate error.");
             	dwRet=TA_FAILED;
                }
        else
              	dwRet=TA_SUCCESS_KILL;
        }

      CloseHandle(hProc) ;
      return dwRet ;
   }

   /*----------------------------------------------------------------
   DWORD WINAPI Terminate16App( DWORD dwPID, DWORD dwThread,
                        WORD w16Task, DWORD dwTimeout )

   Purpose:
      Shut down a Win16 APP.

   Parameters:
      dwPID
         Process ID of the NTVDM in which the 16-bit application is
         running.

      dwThread
         Thread ID of the thread of execution for the 16-bit
         application.

      w16Task
         16-bit task handle for the application.

      dwTimeout
         Wait time in milliseconds before shutting down the task.

   Return Value:
      If successful, returns TA_SUCCESS_16
      If unsuccessful, returns TA_FAILED.
      NOTE:  These values are defined in the header for this
      function.

   NOTE:
      You can get the Win16 task and thread ID through the
      VDMEnumTaskWOW() or the VDMEnumTaskWOWEx() functions.
   ----------------------------------------------------------------*/
   int TJYarrow::Terminate16App( DWORD dwPID, DWORD dwThread,
                        WORD w16Task, DWORD dwTimeout )
   {
      HINSTANCE      hInstLib ;
      TERMINFO      info ;

      // You will be calling the functions through explicit linking
      // so that this code will be binary compatible across
      // Win32 platforms.
      BOOL (WINAPI *lpfVDMTerminateTaskWOW)(DWORD dwProcessId,
         WORD htask) ;

      hInstLib = LoadLibraryA( "VDMDBG.DLL" ) ;
      if( hInstLib == NULL )
         return TA_FAILED ;

      // Get procedure addresses.
      lpfVDMTerminateTaskWOW = (BOOL (WINAPI *)(DWORD, WORD ))
         GetProcAddress( hInstLib, "VDMTerminateTaskWOW" ) ;

      if( lpfVDMTerminateTaskWOW == NULL )
      {
         FreeLibrary( hInstLib ) ;
         return TA_FAILED ;
      }

      // Post a WM_CLOSE to all windows that match the ID and the
      // thread.
      info.dwID = dwPID ;
      info.dwThread = dwThread ;
      EnumWindows((WNDENUMPROC)Terminate16AppEnum, (LPARAM) &info) ;

      // Wait.
      Sleep( dwTimeout ) ;

      // Then terminate.
      lpfVDMTerminateTaskWOW(dwPID, w16Task) ;

      FreeLibrary( hInstLib ) ;
      return TA_SUCCESS_16 ;
   }

   BOOL CALLBACK TerminateAppEnum( HWND hwnd, LPARAM lParam )
   {
      DWORD dwID ;

      GetWindowThreadProcessId(hwnd, &dwID) ;

      if(dwID == (DWORD)lParam)
      {
         PostMessage(hwnd, WM_CLOSE, 0, 0) ;
      }

      return TRUE ;
   }

   BOOL CALLBACK Terminate16AppEnum( HWND hwnd, LPARAM lParam )
   {
      DWORD      dwID ;
      DWORD      dwThread ;
      TERMINFO   *termInfo ;

      termInfo = (TERMINFO *)lParam ;

      dwThread = GetWindowThreadProcessId(hwnd, &dwID) ;

      if(dwID == termInfo->dwID && termInfo->dwThread == dwThread )
      {
         PostMessage(hwnd, WM_CLOSE, 0, 0) ;
      }

      return TRUE ;
   }



DWORD TJYarrow::LookUpProcessName(AnsiString name)
{
	searchCPSAPI cpi;
	DWORD procid;

	cpi.Initialize();
	procid=cpi.LookUpProcessName(name);
	return procid;
}

DWORD TJYarrow::LookUpWindowTitle(AnsiString title)
{
	searchCPSAPI cpi;
	DWORD procid;

	cpi.Initialize();	
	procid=cpi.LookUpWindowTitle(title);
	return procid;
}









































/*
 * C++ Windows process, module enumeration class
 *
 * Written by Lee, JaeKil
 *        mailto:juria@gtech.co.kr
 *
 * Copyright (c) 1998-1999.
 *
 * This code may be used in compiled form in any way you desire. This
 * file may be redistributed unmodified by any means PROVIDING it is 
 * not sold for profit without the authors written consent, and 
 * providing that this notice and the authors name and all copyright 
 * notices remains intact. If the source code in this file is used in 
 * any  commercial application then a statement along the lines of 
 * "Portions copyright (c) Chris Maunder, 1998" must be included in 
 * the startup banner, "About" box or printed documentation. An email 
 * letting me know that you are using it would be nice as well. That's 
 * not much to ask considering the amount of work that went into this.
 *
 * This file is provided "as is" with no expressed or implied warranty.
 * The author accepts no liability for any damage/loss of business that
 * this product may cause.
 *
 * Expect bugs!
 * 
 * Please use and enjoy, and let me know of any bugs/mods/improvements 
 * that you have found/implemented and I will fix/incorporate them into 
 * this file. 
 */

// PSAPI.cpp: implementation of the CPSAPI class.
//
//////////////////////////////////////////////////////////////////////

#include "PSAPI.h"
#include <tlhelp32.h>
#include <vdmdbg.h>
#include <tchar.h>

#define	MAX_HANDLE_COUNT	1024

//////////////////////////////////////////////////////////////////////
// CPSAPI Construction/Destruction

CPSAPI::CPSAPI()
{
	OSVERSIONINFO ovi;
	ovi.dwOSVersionInfoSize = sizeof(ovi);
	GetVersionEx(&ovi);

	// PSAPI is for Windows NT verison 4.0
	if (ovi.dwPlatformId == VER_PLATFORM_WIN32_NT && ovi.dwMajorVersion <= 4)
		{
		// win NT
		m_bNeedPSAPI = true;
		}
	else if (ovi.dwPlatformId == VER_PLATFORM_WIN32_NT && ovi.dwMajorVersion >= 5)
		{
		// ATTN: 8/25/00 added for win 2000 - not tested yet
		m_bNeedPSAPI = true;
		}
	else
		m_bNeedPSAPI = false;		
}


BOOL CPSAPI::Initialize(void)
{
	if ( m_bNeedPSAPI )
	{
		m_modPSAPI = LoadLibrary(_T("PSAPI.DLL"));
		m_modVDMDBG = LoadLibrary(_T("VDMDBG.DLL"));

		if ( m_modPSAPI && m_modVDMDBG )
			return TRUE;
		return FALSE;
	}
	else
	{
	}

	return TRUE;
}

CPSAPI::~CPSAPI()
{
	if ( m_bNeedPSAPI )
	{
		FreeLibrary((HINSTANCE)m_modVDMDBG);
		FreeLibrary((HINSTANCE)m_modPSAPI);
	}
	else
	{
	}
}

//Windows NT Functions
typedef BOOL (WINAPI *ENUMPROCESSES)(
  DWORD * lpidProcess,  // array to receive the process identifiers
  DWORD cb,             // size of the array
  DWORD * cbNeeded      // receives the number of bytes returned
);

typedef BOOL (WINAPI *ENUMPROCESSMODULES)(
  HANDLE hProcess,      // handle to the process
  HMODULE * lphModule,  // array to receive the module handles
  DWORD cb,             // size of the array
  LPDWORD lpcbNeeded    // receives the number of bytes returned
);

typedef DWORD (WINAPI *GETMODULEFILENAMEA)( 
  HANDLE hProcess,		// handle to the process
  HMODULE hModule,		// handle to the module
  LPSTR lpstrFileName,	// array to receive filename
  DWORD nSize			// size of filename array.
);

typedef DWORD (WINAPI *GETMODULEFILENAMEW)( 
  HANDLE hProcess,		// handle to the process
  HMODULE hModule,		// handle to the module
  LPWSTR lpstrFileName,	// array to receive filename
  DWORD nSize			// size of filename array.
);

#ifdef	UNICODE
#define	GETMODULEFILENAME	GETMODULEFILENAMEW
#else
#define	GETMODULEFILENAME	GETMODULEFILENAMEA
#endif

typedef DWORD (WINAPI *GETMODULEBASENAMEA)( 
  HANDLE hProcess,		// handle to the process
  HMODULE hModule,		// handle to the module
  LPTSTR lpstrFileName,	// array to receive base name of module
  DWORD nSize			// size of module name array.
);

typedef DWORD (WINAPI *GETMODULEBASENAMEW)( 
  HANDLE hProcess,		// handle to the process
  HMODULE hModule,		// handle to the module
  LPTSTR lpstrFileName,	// array to receive base name of module
  DWORD nSize			// size of module name array.
);

#ifdef	UNICODE
#define	GETMODULEBASENAME	GETMODULEBASENAMEW
#else
#define	GETMODULEBASENAME	GETMODULEBASENAMEA
#endif

typedef INT (WINAPI *VDMENUMTASKWOWEX)(
  DWORD dwProcessId,	// ID of NTVDM process
  TASKENUMPROCEX fp,	// address of our callback function
  LPARAM lparam);		// anything we want to pass to the callback function.



// Win95 functions
typedef HANDLE (WINAPI *CREATESNAPSHOT)(
    DWORD dwFlags, 
    DWORD th32ProcessID
); 

typedef BOOL (WINAPI *PROCESSWALK)(
    HANDLE hSnapshot,    
    LPPROCESSENTRY32 lppe
);
 
typedef BOOL (WINAPI *MODULEWALK)(
	HANDLE hSnapshot,
	LPMODULEENTRY32 lpme
);
 


BOOL CPSAPI::EnumDeviceDrivers(void)
{
	return FALSE;
}

BOOL CPSAPI::EnumProcesses(void)
{
	if ( m_bNeedPSAPI )
	{
		if ( NULL == m_modPSAPI || NULL == m_modVDMDBG )
			return FALSE;

		ENUMPROCESSES       pEnumProcesses;
		GETMODULEFILENAME   pGetModuleFileName;
		ENUMPROCESSMODULES  pEnumProcessModules;  
		VDMENUMTASKWOWEX	pVDMEnumTaskWOWEx;
		GETMODULEBASENAME	pGetModuleBaseName;

		pVDMEnumTaskWOWEx = (VDMENUMTASKWOWEX)GetProcAddress(m_modVDMDBG, "VDMEnumTaskWOWEx");
		pEnumProcesses = (ENUMPROCESSES)GetProcAddress(m_modPSAPI, "EnumProcesses");
#ifdef	UNICODE
		pGetModuleFileName = (GETMODULEFILENAME)GetProcAddress(m_modPSAPI, "GetModuleFileNameExW");
		pGetModuleBaseName = (GETMODULEBASENAME)GetProcAddress(m_modPSAPI, "GetModuleBaseNameW");
#else
		pGetModuleFileName = (GETMODULEFILENAME)GetProcAddress(m_modPSAPI, "GetModuleFileNameExA");
		pGetModuleBaseName = (GETMODULEBASENAME)GetProcAddress(m_modPSAPI, "GetModuleBaseNameA");
#endif
		pEnumProcessModules = (ENUMPROCESSMODULES)GetProcAddress(m_modPSAPI, "EnumProcessModules");

		if (
			NULL == pVDMEnumTaskWOWEx	||
			NULL == pEnumProcesses		|| 
			NULL == pGetModuleFileName	|| 
			NULL == pGetModuleBaseName	||
			NULL == pEnumProcessModules  )
			return FALSE;

		DWORD nProcessIDs[MAX_HANDLE_COUNT];
		DWORD nProcessNo;

		BOOL bSuccess = pEnumProcesses(nProcessIDs, sizeof(nProcessIDs), &nProcessNo);
		nProcessNo /= sizeof(nProcessIDs[0]);

		if ( !bSuccess )
		{
			return FALSE;
		}  

		for ( unsigned i=0; i<nProcessNo; i++)
		{
			HANDLE process = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, 
								FALSE, nProcessIDs[i]);

			HMODULE hModules[MAX_HANDLE_COUNT];
			DWORD nModuleNo;
			TCHAR szFileName[MAX_PATH];

			pEnumProcessModules(process, hModules, sizeof(hModules), &nModuleNo);

			nModuleNo /= sizeof(hModules[0]);

			if ( pGetModuleFileName(process, hModules[0], szFileName, sizeof(szFileName)) )
			{
				if ( OnProcess(szFileName, nProcessIDs[i]) == FALSE )
					break;

				pGetModuleBaseName(process, hModules[0], szFileName, sizeof(szFileName));

				if ( 0 == _tcsicmp(szFileName, _T("NTVDM.EXE")) )
				{
					// We've got an NT VDM -- enumerate the processes
					// it contains.
//					pVDMEnumTaskWOWEx(nProcessIDs[i], show_task, (long)&disp);
				}
			}
			CloseHandle(process);
		}

		return TRUE;
	}
	else
	{
		HINSTANCE modKERNEL = GetModuleHandle(_T("KERNEL32.DLL"));

		CREATESNAPSHOT CreateToolhelp32Snapshot; 
		PROCESSWALK pProcess32First; 
		PROCESSWALK pProcess32Next; 

		CreateToolhelp32Snapshot = (CREATESNAPSHOT)GetProcAddress(modKERNEL, "CreateToolhelp32Snapshot"); 
		pProcess32First = (PROCESSWALK)GetProcAddress(modKERNEL, "Process32First"); 
		pProcess32Next  = (PROCESSWALK)GetProcAddress(modKERNEL, "Process32Next"); 

		if (
			NULL == CreateToolhelp32Snapshot	|| 
			NULL == pProcess32First				||
			NULL == pProcess32Next)
			return FALSE;

		PROCESSENTRY32 proc;
		proc.dwSize = sizeof(proc);

		HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
		/* Now that we have a snapshot of the system state, we simply
		* walk the list it represents by calling Process32First once,
		* then call Proces32Next repeatedly until we get to the end 
		* of the list.
		*/
		pProcess32First(snapshot, &proc);
		if ( OnProcess(proc.szExeFile, proc.th32ProcessID) == FALSE )
		{
			CloseHandle(snapshot);
			return TRUE;
		}

		while ( pProcess32Next(snapshot, &proc) )
			if ( OnProcess(proc.szExeFile, proc.th32ProcessID) == FALSE )
				break;

		/* This should happen automatically when we terminate, but it never
		* hurts to clean up after ourselves.
		*/
		CloseHandle(snapshot);

		return TRUE;
	}
}

BOOL CPSAPI::EnumProcessModules(DWORD dwProcessId)
{
	if ( m_bNeedPSAPI )
	{
		if ( NULL == m_modPSAPI || NULL == m_modVDMDBG )
			return FALSE;

		ENUMPROCESSES       pEnumProcesses;
		GETMODULEFILENAME   pGetModuleFileName;
		ENUMPROCESSMODULES  pEnumProcessModules;  
		VDMENUMTASKWOWEX	pVDMEnumTaskWOWEx;
		GETMODULEBASENAME	pGetModuleBaseName;

		pVDMEnumTaskWOWEx = (VDMENUMTASKWOWEX)GetProcAddress(m_modVDMDBG, "VDMEnumTaskWOWEx");
		pEnumProcesses = (ENUMPROCESSES)GetProcAddress(m_modPSAPI, "EnumProcesses");
#ifdef	UNICODE
		pGetModuleFileName = (GETMODULEFILENAME)GetProcAddress(m_modPSAPI, "GetModuleFileNameExW");
		pGetModuleBaseName = (GETMODULEBASENAME)GetProcAddress(m_modPSAPI, "GetModuleBaseNameW");
#else
		pGetModuleFileName = (GETMODULEFILENAME)GetProcAddress(m_modPSAPI, "GetModuleFileNameExA");
		pGetModuleBaseName = (GETMODULEBASENAME)GetProcAddress(m_modPSAPI, "GetModuleBaseNameA");
#endif
		pEnumProcessModules = (ENUMPROCESSMODULES)GetProcAddress(m_modPSAPI, "EnumProcessModules");

		if ( NULL == pGetModuleFileName ||
			NULL == pEnumProcessModules  )
			return FALSE;

		HMODULE hModules[MAX_HANDLE_COUNT];
		DWORD nModuleNo;

		HANDLE process = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, dwProcessId);
		if ( process == NULL )
			return FALSE;

		BOOL bSuccess = pEnumProcessModules(process, hModules, sizeof(hModules), &nModuleNo);
		nModuleNo /= sizeof(hModules[0]);

		if ( !bSuccess )
		{
			CloseHandle(process);
			return FALSE;
		}

		TCHAR szFileName[MAX_PATH];
		for ( unsigned i=0; i<nModuleNo; i++)
		{
			if ( pGetModuleFileName(process, hModules[i], szFileName, sizeof(szFileName)) == FALSE )
			{
				CloseHandle(process);
				return FALSE;
			}

			LPTSTR szSep = _tcsrchr(szFileName, '\\');
			if ( szSep )
				szSep++;

			if ( OnModule(hModules[i], szFileName, szSep ) == FALSE )
				break;
		}

		CloseHandle(process);
		return TRUE;
	}
	else
	{
		HINSTANCE modKERNEL = GetModuleHandle(_T("KERNEL32.DLL"));

		CREATESNAPSHOT CreateToolhelp32Snapshot; 
		MODULEWALK pModule32First; 
		MODULEWALK pModule32Next; 

		CreateToolhelp32Snapshot = (CREATESNAPSHOT)GetProcAddress(modKERNEL, "CreateToolhelp32Snapshot"); 
		pModule32First = (MODULEWALK)GetProcAddress(modKERNEL, "Module32First"); 
		pModule32Next  = (MODULEWALK)GetProcAddress(modKERNEL, "Module32Next"); 

		if (
			NULL == CreateToolhelp32Snapshot	|| 
			NULL == pModule32First				||
			NULL == pModule32Next)
			return FALSE;

		MODULEENTRY32 module;
		module.dwSize = sizeof(module);

		HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessId);
		/* Now that we have a snapshot of the system state, we simply
		* walk the list it represents by calling Process32First once,
		* then call Proces32Next repeatedly until we get to the end 
		* of the list.
		*/
		pModule32First(snapshot, &module);
		if ( OnModule(module.hModule, module.szExePath, module.szModule) == FALSE )
		{
			CloseHandle(snapshot);
			return TRUE;
		}

		while ( pModule32Next(snapshot, &module) )
			if ( OnModule(module.hModule, module.szExePath, module.szModule) == FALSE )
				break;

		/* This should happen automatically when we terminate, but it never
		* hurts to clean up after ourselves.
		*/
		CloseHandle(snapshot);
		return TRUE;
	}
}


//////////////////////////////////////////////////////////////////////
// CPSAPI Overridables

BOOL CPSAPI::OnDeviceDriver(LPVOID lpImageBase)
{
	return TRUE;
}

BOOL CPSAPI::OnProcess(LPCTSTR lpszFileName, DWORD ProcessID)
{
	return TRUE;
}

BOOL CPSAPI::OnModule(HMODULE hModule, LPCTSTR lpszModuleName, LPCTSTR lpszPathName)
{
	return TRUE;
}

















 
DWORD searchCPSAPI::LookUpProcessName(AnsiString name)
{
	procname=name.LowerCase();
	procid=0;
	EnumProcesses();
	return procid;
}

DWORD searchCPSAPI::LookUpWindowTitle(AnsiString title)
{
	wintitle=title.LowerCase();
	procid=0;
	EnumProcesses();
	return procid;
}

BOOL searchCPSAPI::OnDeviceDriver(LPVOID lpImageBase)
{
	return TRUE;
}

BOOL searchCPSAPI::OnProcess(LPCTSTR lpszFileName, DWORD ProcessID)
{
	AnsiString p1;
	p1=AnsiString(lpszFileName).LowerCase();
	if (p1.Pos(procname)!=0)
		procid=ProcessID;
	if (p1.Pos(wintitle)!=0)
		procid=ProcessID;
	return TRUE;
}

BOOL searchCPSAPI::OnModule(HMODULE hModule, LPCTSTR lpszModuleName, LPCTSTR lpszPathName)
{
	return TRUE;
}

